$(function(){

	function createCarousel(name, items, arrowClass, destroy) {
		if(destroy == 1) {
			$(name).trigger("destroy", true);
		}
		
		$(name).carouFredSel({
			items				: items,
			direction			: "left",
			auto				: false,
			responsive			: false,
			circular			: false,
			infinite			: false,
			scroll : {
				items			: 1,
				easing			: "easeInOutQuint",
				duration		: 1000,
				pauseOnHover	: true
			},
			prev : {
				button : arrowClass + " .left_arrow",
				key : "left"
			},
			next : { 
				button : arrowClass + " .right_arrow",
				key : "right"
			},
			swipe : {
				onTouch : true,
				onMouse : false
			}
		});
	}

	$(document).ready(function(){
		//Create initial carousel
		var breakpoint = $('.current_breakpoint').width();

		if(breakpoint == '900') {
			createCarousel('.related_products', 3, '.blockproductscategory');

		} else if(breakpoint == '600') {
			createCarousel('.related_products', 2, '.blockproductscategory');

		} else if(breakpoint == '1') {
			createCarousel('.related_products', 1, '.blockproductscategory');

		} else if(breakpoint == '1000') {
			createCarousel('.related_products', 4, '.blockproductscategory');
		}

		//Change carousel on window resize
		$(window).resize(function() {
			var breakpoint = $('.current_breakpoint').width();

			if(breakpoint == '900') {
				createCarousel('.related_products', 3, '.blockproductscategory', 1);

			} else if(breakpoint == '600') {
				createCarousel('.related_products', 2, '.blockproductscategory', 1);

			} else if(breakpoint == '1') {
				createCarousel('.related_products', 1, '.blockproductscategory', 1);

			} else if(breakpoint == '1000') {
				createCarousel('.related_products', 4, '.blockproductscategory', 1);
			}
		});
	});
});