$(function(){
	$(document).ready(function(){
		//Plus button
		$(".product_plus").click(
			function () {
				var currentValue = $('#quantity_wanted').val();
				currentValue = parseInt(currentValue, 10) + 1;

				$('#quantity_wanted').val(currentValue);
			}
		);

		//Minus button
		$(".product_minus").click(
			function () {
				var currentValue = $('#quantity_wanted').val();
				currentValue = parseInt(currentValue, 10) - 1;

				if( currentValue > 0 )
					$('#quantity_wanted').val(currentValue);
			}
		);
	});
});