$(function(){
	$(document).ready(function(){
		$(".product_list ul li .product_image").live({
			mouseenter:
			   function () {
					$(this).children(".product_hover_box").fadeOut(0);
					$(this).children(".product_hover_box").stop();
					if ($.browser.msie && $.browser.version == '8.0') {
						$(this).children(".product_hover_box").fadeTo(300, 0.3);
					} else {
						$(this).children(".product_hover_box").fadeIn(300);
					}

					$(this).children(".add_to_cart").fadeOut(0);
					$(this).children(".add_to_cart").stop();
					$(this).children(".add_to_cart").fadeIn(300);

					$(this).children(".view_product").fadeOut(0);
					$(this).children(".view_product").stop();
					$(this).children(".view_product").fadeIn(300);
				},
			mouseleave:
				function () {
					$(this).children(".product_hover_box").stop();
					$(this).children(".product_hover_box").fadeOut(300);

					$(this).children(".add_to_cart").stop();
					$(this).children(".add_to_cart").fadeOut(300);

					$(this).children(".view_product").stop();
					$(this).children(".view_product").fadeOut(300);
				}
		});
		
		$(".product_column .container").hover(
			function () {
				$(this).children(".product_hover_box").fadeOut(0);
				$(this).children(".product_hover_box").stop();
				if ($.browser.msie && $.browser.version == '8.0') {
					$(this).children(".product_hover_box").fadeTo(300, 0.3);
				} else {
					$(this).children(".product_hover_box").fadeIn(300);
				}
				
				$(this).children(".content").fadeOut(0);
				$(this).children(".content").stop();
				$(this).children(".content").fadeIn(300);
			},
			function () {
				$(this).children(".product_hover_box").stop();
				$(this).children(".product_hover_box").fadeOut(300);
				
				$(this).children(".content").stop();
				$(this).children(".content").fadeOut(300);
			}
		);

	});
});