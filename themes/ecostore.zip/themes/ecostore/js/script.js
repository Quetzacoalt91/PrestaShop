
$("#columns").on("hover", "#product_list li .product_img_link", function(e) {

        if (e.type == "mouseenter") {
        
            $(this).find(".img_1").stop().fadeIn("fast");

        } else {// mouseleave
    
    $(this).find(".img_1").stop().fadeOut("fast");

        }
    });
    
      if (runFancy) {
    
        $("#columns").on("hover", "#product_list li", function(e) {

        if (e.type == "mouseenter") {
        $(".product_img_link", this).stop().fadeTo("fast", 0.8);

        } else {// mouseleave
         $(".product_img_link", this).stop().fadeTo("fast", 1.0);

        }
    });
    }
