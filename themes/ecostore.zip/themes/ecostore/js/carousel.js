$(function(){

	function createCarousel(name, items, arrowClass, destroy) {
		if(destroy == 1) {
			$(name).trigger("destroy", true);
		}

		$(name).carouFredSel({
			items				: items,
			direction			: "left",
			auto				: false,
			responsive			: false,
			circular			: false,
			infinite			: false,
			scroll : {
				items			: 1,
				easing			: "easeInOutQuint",
				duration		: 1000,
				pauseOnHover	: true
			},
			prev : {
				button : arrowClass + " .left_arrow",
				key : "left"
			},
			next : { 
				button : arrowClass + " .right_arrow",
				key : "right"
			},
			swipe : {
				onTouch : true,
				onMouse : false
			}
		});
	}

	$(document).ready(function(){
		//Create initial carousels
		var breakpoint = $('.current_breakpoint').width();

		if(breakpoint == '900') {
			createCarousel('.featured_products', 3, '.featured');
			createCarousel('.latest_products', 3, '.latest');
			createCarousel('.brand_list', 4, '.brand_slider');

		} else if(breakpoint == '600') {
			createCarousel('.featured_products', 2, '.featured');
			createCarousel('.latest_products', 2, '.latest');
			createCarousel('.brand_list', 3, '.brand_slider');

		} else if(breakpoint == '1') {
			createCarousel('.featured_products', 1, '.featured');
			createCarousel('.latest_products', 1, '.latest');
			createCarousel('.brand_list', 1, '.brand_slider');

		} else if(breakpoint == '1000') {
			createCarousel('.featured_products', 4, '.featured');
			createCarousel('.latest_products', 4, '.latest');
			createCarousel('.brand_list', 5, '.brand_slider');
		}

		//Change carousels on window resize
		$(window).resize(function() {
			var breakpoint = $('.current_breakpoint').width();

			if(breakpoint == '900') {

				createCarousel('.featured_products', 3, '.featured', 1);
				createCarousel('.latest_products', 3, '.latest', 1);
				createCarousel('.brand_list', 4, '.brand_slider', 1);

			} else if(breakpoint == '600') {

				createCarousel('.featured_products', 2, '.featured', 1);
				createCarousel('.latest_products', 2, '.latest', 1);
				createCarousel('.brand_list', 3, '.brand_slider', 1);

			} else if(breakpoint == '1') {

				createCarousel('.featured_products', 1, '.featured', 1);
				createCarousel('.latest_products', 1, '.latest', 1);
				createCarousel('.brand_list', 1, '.brand_slider', 1);

			} else if(breakpoint == '1000') {

				createCarousel('.featured_products', 4, '.featured', 1);
				createCarousel('.latest_products', 4, '.latest', 1);
				createCarousel('.brand_list', 5, '.brand_slider', 1);

			}
		});
		
	});
});