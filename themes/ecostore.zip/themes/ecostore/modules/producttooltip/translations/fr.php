<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{producttooltip}ecostore>producttooltip_4776f7eb5998034f7bbc63b6457d1ff4'] = 'Infobulles produit';
$_MODULE['<{producttooltip}ecostore>producttooltip_3e29935c25a10ae452308dc52381f353'] = 'Affiche combien de personnes consultent un produit ainsi que les dates de dernière commande ou ajout au panier';
$_MODULE['<{producttooltip}ecostore>producttooltip_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{producttooltip}ecostore>producttooltip_e548d0d6a94a27306b8b31472a3e5ec3'] = 'Afficher le nombre de personnes qui consultent la fiche produit ?';
$_MODULE['<{producttooltip}ecostore>producttooltip_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{producttooltip}ecostore>producttooltip_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{producttooltip}ecostore>producttooltip_2c8de3180924949acc5f6250af689802'] = 'Période de validité :';
$_MODULE['<{producttooltip}ecostore>producttooltip_640fd0cc0ffa0316ae087652871f4486'] = 'minutes';
$_MODULE['<{producttooltip}ecostore>producttooltip_8a8110f8a25a0e445f51edf84fd98a96'] = 'Si vous activez l\'option ci-dessus, vous devez activer la première option du module StatData';
$_MODULE['<{producttooltip}ecostore>producttooltip_1e358b149c2d4105f3a74c1961d1d9fb'] = 'Afficher la date de la dernière commande ?';
$_MODULE['<{producttooltip}ecostore>producttooltip_dbcfa4aa50cd5f7ad099b3ba50e1137c'] = 'Si aucune commande à afficher, afficher la date du dernier ajout au panier ?';
$_MODULE['<{producttooltip}ecostore>producttooltip_a536f110cc080569666e95e8f49fda9b'] = 'Ne pas afficher les événements datant de plus de :';
$_MODULE['<{producttooltip}ecostore>producttooltip_44fdec47036f482b68b748f9d786801b'] = 'jours';
$_MODULE['<{producttooltip}ecostore>producttooltip_b17f3f4dcf653a5776792498a9b44d6a'] = 'Mettre à jour les paramètres';
$_MODULE['<{producttooltip}ecostore>producttooltip_f0f5fac9602d88bc27f0edf960dda8b8'] = 'Exemple :';
$_MODULE['<{producttooltip}ecostore>producttooltip_a49dc1bf9fb1e2ba1c9735f91dfece9a'] = '%d personne regarde actuellement ce produit';
$_MODULE['<{producttooltip}ecostore>producttooltip_d33e6930ab863734cef083b815ff7356'] = '%d personnes regardent actuellement ce produit';
$_MODULE['<{producttooltip}ecostore>producttooltip_71736c614b237f4368128077411f1699'] = 'Ce produit a été acheté dernièrement le';
$_MODULE['<{producttooltip}ecostore>producttooltip_4dda321f0231c2d50fcee5c20075dbbd'] = 'Ce produit a été ajouté au panier dernièrement le';
