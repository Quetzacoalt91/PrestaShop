<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{producttooltip}ecostore>producttooltip_4776f7eb5998034f7bbc63b6457d1ff4'] = 'Ventana de información producto';
$_MODULE['<{producttooltip}ecostore>producttooltip_3e29935c25a10ae452308dc52381f353'] = 'Mostrar cuántas personas están viendo la página del producto, así como la fecha del último producto pedido o incluido en el carrito';
$_MODULE['<{producttooltip}ecostore>producttooltip_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{producttooltip}ecostore>producttooltip_e548d0d6a94a27306b8b31472a3e5ec3'] = '¿Mostrar el número de personas que están viendo este producto?';
$_MODULE['<{producttooltip}ecostore>producttooltip_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{producttooltip}ecostore>producttooltip_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{producttooltip}ecostore>producttooltip_2c8de3180924949acc5f6250af689802'] = 'Periodo de validez:';
$_MODULE['<{producttooltip}ecostore>producttooltip_640fd0cc0ffa0316ae087652871f4486'] = 'minutos';
$_MODULE['<{producttooltip}ecostore>producttooltip_8a8110f8a25a0e445f51edf84fd98a96'] = 'Si activa la opción anterior, debe activar la primera opción del módulo StatData';
$_MODULE['<{producttooltip}ecostore>producttooltip_1e358b149c2d4105f3a74c1961d1d9fb'] = '¿Mostrar la fecha del último pedido?';
$_MODULE['<{producttooltip}ecostore>producttooltip_dbcfa4aa50cd5f7ad099b3ba50e1137c'] = 'Si no hay pedido, ¿mostrar la última vez que un producto ha sido añadido al carrito?';
$_MODULE['<{producttooltip}ecostore>producttooltip_a536f110cc080569666e95e8f49fda9b'] = 'No mostrar los acontecimientos de más de:';
$_MODULE['<{producttooltip}ecostore>producttooltip_44fdec47036f482b68b748f9d786801b'] = 'días';
$_MODULE['<{producttooltip}ecostore>producttooltip_b17f3f4dcf653a5776792498a9b44d6a'] = 'Actualizar configuración';
$_MODULE['<{producttooltip}ecostore>producttooltip_f0f5fac9602d88bc27f0edf960dda8b8'] = 'Mostrar:';
$_MODULE['<{producttooltip}ecostore>producttooltip_a49dc1bf9fb1e2ba1c9735f91dfece9a'] = '%d persona que está viendo en este momento este producto';
$_MODULE['<{producttooltip}ecostore>producttooltip_d33e6930ab863734cef083b815ff7356'] = '%d personas que están viendo en este momento este producto';
$_MODULE['<{producttooltip}ecostore>producttooltip_71736c614b237f4368128077411f1699'] = 'Este producto fue comprado por última vez el';
$_MODULE['<{producttooltip}ecostore>producttooltip_4dda321f0231c2d50fcee5c20075dbbd'] = 'Este producto fue añadido al carrito por última vez el';
