<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}ecostore>blockpaymentlogo_ea2d4e3948f9543e5939efd1663ddef5'] = 'Bloc logo de paiement';
$_MODULE['<{blockpaymentlogo}ecostore>blockpaymentlogo_d272c8b17089521db4660c7852f8839c'] = 'Ajoute un bloc affichant tous les logos des modes de paiement.';
$_MODULE['<{blockpaymentlogo}ecostore>blockpaymentlogo_fb0c64625321a2f2e5e8800a7ddbd759'] = 'Logo de paiement';
$_MODULE['<{blockpaymentlogo}ecostore>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Paramètres mis à jour';
$_MODULE['<{blockpaymentlogo}ecostore>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Aucune page CMS n\'est disponible';
$_MODULE['<{blockpaymentlogo}ecostore>blockpaymentlogo_f1206f9fadc5ce41694f69129aecac26'] = 'Configurer';
$_MODULE['<{blockpaymentlogo}ecostore>blockpaymentlogo_4b3c34d991275b9fdb0facfcea561be9'] = 'Page CMS pour le lien';
$_MODULE['<{blockpaymentlogo}ecostore>blockpaymentlogo_01bb71b3e70e9e5057c9678a903d47ac'] = 'Choisir une page';
$_MODULE['<{blockpaymentlogo}ecostore>blockpaymentlogo_d4dccb8ca2dac4e53c01bd9954755332'] = 'Enregistrer les paramètres';
