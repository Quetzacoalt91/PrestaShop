<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers-home_3cb29f0ccc5fd220a97df89dafe46290'] = 'Meilleures ventes';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers-home_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Plus d\'infos';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers-home_4351cfebe4b61d8aa5efa1d020710005'] = 'Voir';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers-home_eae99cd6a931f3553123420b16383812'] = 'Toutes les meilleures ventes';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers-home_adc570b472f54d65d3b90b8cee8368a9'] = 'Pas encore de meilleure vente';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_ee520a08f4b3f527b11c4316aa399e84'] = 'Bloc meilleures ventes';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_4f6db60ed6f1c8555648014427822faf'] = 'Ajoute un bloc qui affiche les meilleures ventes de la boutique';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_41385d2dca40c2a2c7062ed7019a20be'] = 'Toujours afficher ce bloc';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_53d61d1ac0507b1bd8cd99db8d64fb19'] = 'Afficher ce bloc même si aucun produit disponible';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Meilleures ventes';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Toutes les meilleures ventes';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Pas encore de meilleure vente';
$_MODULE['<{blockbestsellers}ecostore>blockbestsellers-home_f7be84d6809317a6eb0ff3823a936800'] = 'Pas encore de meilleure vente';
