<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockviewed}ecostore>blockviewed_fcb72d5a95d9a713f84425c807bbd667'] = 'Bloque de productos vistos';
$_MODULE['<{blockviewed}ecostore>blockviewed_eaa362292272519b786c2046ab4b68d2'] = 'Añadir un bloque para mostrar los últimos productos vistos';
$_MODULE['<{blockviewed}ecostore>blockviewed_2e57399079951d84b435700493b8a8c1'] = 'Debe rellenar el campo\'Productos mostrados';
$_MODULE['<{blockviewed}ecostore>blockviewed_73293a024e644165e9bf48f270af63a0'] = 'Número no válido.';
$_MODULE['<{blockviewed}ecostore>blockviewed_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{blockviewed}ecostore>blockviewed_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blockviewed}ecostore>blockviewed_e451e6943bb539d1bd804d2ede6474b5'] = 'Productos mostrados';
$_MODULE['<{blockviewed}ecostore>blockviewed_d36bbb6066e3744039d38e580f17a2cc'] = 'Definir el número de productos mostrados en cada bloque';
$_MODULE['<{blockviewed}ecostore>blockviewed_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockviewed}ecostore>blockviewed_43560641f91e63dc83682bc598892fa1'] = 'Productos más vistos';
$_MODULE['<{blockviewed}ecostore>blockviewed_8f7f4c1ce7a4f933663d10543562b096'] = 'Más sobre';
$_MODULE['<{blockviewed}ecostore>blockviewed_49fa2426b7903b3d4c89e2c1874d9346'] = 'Más sobre';
