<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{minicslider}ecostore>javascript_93caeaee939951cb0a9bce4917cf7b4a'] = 'cliquer';
$_MODULE['<{minicslider}ecostore>front_14230d11143a03f4330c6433d5032a9d'] = 'Précédent';
$_MODULE['<{minicslider}ecostore>front_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Suivant';
