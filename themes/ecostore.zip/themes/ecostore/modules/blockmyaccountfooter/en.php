<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_057d295c52fbfa6009018983adfcfef3'] = 'My orders';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_84717c9dceaf4edb4d68fb83baad9c5b'] = 'My returns';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_adb86424a996157ea978c08a665aa552'] = 'My credit slips';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_ce1f9a653c6297bee14973a2af3c4493'] = 'My addresses';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_1f94d078255c7cee3fcfd50c762101e6'] = 'My vouchers';
