<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_db5bbee0cb649caceaa88f704351ac80'] = 'Nouveautés';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Infos';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_f2cd171bd42220283b7a595c3ff2aaaf'] = 'Solde';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_4351cfebe4b61d8aa5efa1d020710005'] = 'Voir';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_e0e572ae0d8489f8bf969e93d469e89c'] = 'Aucun nouveau produit';
