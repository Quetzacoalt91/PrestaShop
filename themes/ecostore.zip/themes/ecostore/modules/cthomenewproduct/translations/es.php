<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_09ced8258545d3510049c961acb7465a'] = 'Novedades';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_db5bbee0cb649caceaa88f704351ac80'] = 'Novedades';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Mas info';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_f2cd171bd42220283b7a595c3ff2aaaf'] = 'Rebajas';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuevo';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_2d0f6b8300be19cf35e89e66f0677f95'] = 'añadir al carrito';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_4351cfebe4b61d8aa5efa1d020710005'] = 'Ver';
$_MODULE['<{cthomenewproduct}ecostore>cthomenewproduct_e0e572ae0d8489f8bf969e93d469e89c'] = 'No novedades';
