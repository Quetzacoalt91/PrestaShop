<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{editorial}ecostore>editorial_a46dcd3561c3feeb53903dfc0f796a35'] = 'Editeur de page d\'accueil';
$_MODULE['<{editorial}ecostore>editorial_48b5a6f8c5a4e81cd8eb07678a981649'] = 'Un éditeur de texte pour votre page d\'accueil.';
$_MODULE['<{editorial}ecostore>editorial_5db205c79efd29b0e4f52d0c1ff45d20'] = 'Sauvegarder';
$_MODULE['<{editorial}ecostore>editorial_0245625ee10f9c6c0ed7f50eb1838856'] = 'Titre principal';
$_MODULE['<{editorial}ecostore>editorial_4fb7f07fcf38a6401743822ade34e782'] = 'Apparaît en haut de la page d\'accueil';
$_MODULE['<{editorial}ecostore>editorial_e1f46be647e598f00eeb0ab62561d695'] = 'Pré-en-tête';
$_MODULE['<{editorial}ecostore>editorial_bf75f228011d1443c4ea7aca23c3cff2'] = 'Texte d\'introduction';
$_MODULE['<{editorial}ecostore>editorial_617f7661941abbf06f773fcb10031c7a'] = 'Texte d\'introduction de votre choix ; expliquez par exemple ce que vous vendez, mettez en avant un produit, ou racontez un évènement récent.';
$_MODULE['<{editorial}ecostore>editorial_78587f196180054fcb797d40f4a86f10'] = 'Logo de la page d\'accueil';
$_MODULE['<{editorial}ecostore>editorial_28d74ee805e3a162047d8f917b74dcb3'] = 'Lien de l\'image';
$_MODULE['<{editorial}ecostore>editorial_98039e8f2a0d93fc0fff503f9166f59b'] = 'Sous-titre de l\'image';
$_MODULE['<{editorial}ecostore>editorial_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{editorial}ecostore>editorial_2563cfff94f1447b53116f3089940125'] = 'Vous ne pouvez pas effectuer cette action.';
$_MODULE['<{editorial}ecostore>editorial_5526efd7014a00a73115bcf90883d968'] = 'Une erreur est survenue lors de l\'upload de l\'image.';
$_MODULE['<{editorial}ecostore>editorial_8dd2f915acf4ec98006d11c9a4b0945b'] = 'Paramètres mis à jour avec succès';
