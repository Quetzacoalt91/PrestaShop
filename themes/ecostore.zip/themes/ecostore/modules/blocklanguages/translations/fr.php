<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}ecostore>blocklanguages_d5988791c07fedc0e2fc77683b4e61f6'] = 'Bloc langues';
$_MODULE['<{blocklanguages}ecostore>blocklanguages_5b2b53f769604bcbee6f67882c73fb94'] = 'Ajoute un bloc permettant au client de choisir sa langue';
