<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockspecials}ecostore>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Bloque promociones especiales';
$_MODULE['<{blockspecials}ecostore>blockspecials_42bcf407ca1621390ed7cbea2b2c0c62'] = 'Añadir un bloque con promociones especiales';
$_MODULE['<{blockspecials}ecostore>blockspecials_c888438d14855d7d96a2724ee9c306bd'] = 'Parámetros actualizados';
$_MODULE['<{blockspecials}ecostore>blockspecials_f4f70727dc34561dfde1a3c529b6205c'] = 'Parámetros ';
$_MODULE['<{blockspecials}ecostore>blockspecials_41385d2dca40c2a2c7062ed7019a20be'] = 'Mostrar este bloque siempre';
$_MODULE['<{blockspecials}ecostore>blockspecials_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blockspecials}ecostore>blockspecials_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blockspecials}ecostore>blockspecials_a8a670d89a6d2f3fa59942fc591011ef'] = 'Mostrar este bloque aunque no haya productos disponibles';
$_MODULE['<{blockspecials}ecostore>blockspecials_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockspecials}ecostore>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Promociones especiales';
$_MODULE['<{blockspecials}ecostore>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Todas los promociones especiales';
$_MODULE['<{blockspecials}ecostore>blockspecials_077a28bcf4e93718e678ec57128669a3'] = 'No hay promociones especiales en este momento';
$_MODULE['<{blockspecials}ecostore>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'No hay promociones especiales en este momento';
