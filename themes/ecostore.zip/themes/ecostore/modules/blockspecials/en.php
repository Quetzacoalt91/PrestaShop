<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockspecials}prestashop>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'No product specials are available at this time.';
