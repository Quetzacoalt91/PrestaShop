<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccount}ecostore>blockmyaccount_ecf3e4f8f34a293099620cc25d5b4d93'] = 'Bloque Mi cuenta';
$_MODULE['<{blockmyaccount}ecostore>blockmyaccount_ecf2ffd31994b3edea4b916011b08bfa'] = 'Mostrar un bloque con enlaces a la cuenta del usuario';
