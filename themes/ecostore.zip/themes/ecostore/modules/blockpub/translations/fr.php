<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpub}homshop>blockpub_a7339a98fd0ebea5ed982f92eed11c70'] = 'Ajoute un bloc affichant une publicité';
$_MODULE['<{blockpub}homshop>blockpub_226ed577d0eff50725be6447bcd5a2f0'] = 'Erreur de déplacement du fichier mis en ligne';
$_MODULE['<{blockpub}homshop>blockpub_a21056e22c4d62b400b5dd96dafe22a3'] = 'Vous ne pouvez pas supprimer l\'image par défaut (Mais vous pouvez la modifier ci-dessous)';
$_MODULE['<{blockpub}homshop>blockpub_83b5a65e518c21ed0a5f2b383dd9b617'] = 'Supprimer l\'image';
$_MODULE['<{blockpub}homshop>blockpub_706bebc78ad992a07e4c1ce0f39def81'] = 'pas d\'image';
$_MODULE['<{blockpub}homshop>blockpub_8c38cf08a0d0a01bd44c682479432350'] = 'Changer l\'image';
$_MODULE['<{blockpub}homshop>blockpub_9ce38727cff004a058021a6c7351a74a'] = 'Lien de l\'image';
$_MODULE['<{blockpub}homshop>blockpub_b78a3223503896721cca1303f776159b'] = 'Titre';
$_MODULE['<{blockpub}homshop>blockpub_ad3d06d03d94223fa652babc913de686'] = 'Valider';
