<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{feeder}ecostore>feeder_d97c951c07d785b317ffb55c01bf6976'] = 'Flux RSS des produits';
$_MODULE['<{feeder}ecostore>feeder_b118eb1df6ece770ad9d2bbe97cc1a79'] = 'Générer un flux RSS des produits';
