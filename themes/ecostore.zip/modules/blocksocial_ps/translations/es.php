<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksocial_ps}prestashop>blocksocial_ps_d855ede707b7d778b3fb19309997c90e'] = 'Le permite agregar información adicional sobre las redes sociales';
$_MODULE['<{blocksocial_ps}prestashop>blocksocial_ps_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuración actualizada';
$_MODULE['<{blocksocial_ps}prestashop>blocksocial_ps_f95f7cbc540537a1010c5b545eb67339'] = 'Facebook URL:';
$_MODULE['<{blocksocial_ps}prestashop>blocksocial_ps_e62adc7f2754307e0a31f145e29f6be1'] = 'Twitter URL:';
$_MODULE['<{blocksocial_ps}prestashop>blocksocial_ps_77e4dcd265e823af4b5d59f6fa23dfa3'] = 'RSS URL:';
$_MODULE['<{blocksocial_ps}prestashop>blocksocial_ps_b17f3f4dcf653a5776792498a9b44d6a'] = 'Ajustes actualizados';
$_MODULE['<{blocksocial_ps}prestashop>blocksocial_ps_d918f99442796e88b6fe5ad32c217f76'] = 'Siganos';
