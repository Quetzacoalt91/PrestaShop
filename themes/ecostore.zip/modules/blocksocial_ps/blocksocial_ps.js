
$(document).ready(function() {

	
			$("#social_block_ps li a").hover(
  function () {
   $(this).stop().animate({ backgroundPosition : "0 -32"}, {queue:false, duration: 200});
  },
  function () {
    $(this).stop().animate({ backgroundPosition : "0 0"}, {queue:false, duration: 200});
	
	 
  }
);
});