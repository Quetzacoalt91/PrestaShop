<?php

if (!defined('_PS_VERSION_'))
	exit;

class ThemesEditor extends Module
{
	private $_html = '';
	private $image;
	private $content;
	private $link;
	private $_postErrors = array();
	private $google_fonts_link = '';
	private $custom_colors;
	private $logo_style = '';

	function __construct()
	{
		$this->name = 'themeseditor';
		$this->tab = 'front_office_features';
		$this->version = '1.0';
		$this->need_instance = 0;

		parent::__construct();

		$this->displayName = $this->l('Themes Editor');
		$this->description = $this->l('Change your theme editor.');
	}

	function install()
	{
		if (!parent::install() || !$this->registerHook('displayHeader') || !$this->installDB())
			return false;
		return true;
	}

	public function uninstall()
	{
		if (!parent::uninstall() ||
			!$this->uninstallDB())
			return false;
		return true;
	}

	public function installDb()
	{
		if( !Configuration::updateGlobalValue('titlepage_img', 'titlepage.png') ||
			!Configuration::updateGlobalValue('logo_top', '46') ||
			!Configuration::updateGlobalValue('logo_left', '5') ||
			!Configuration::updateGlobalValue('theme_responsive', 'on') ||
			!Configuration::updateGlobalValue('sidebar_position', 'left') ||
			!Configuration::updateGlobalValue('footer_bg', '5a5858') ||
			!Configuration::updateGlobalValue('footer_copyright_text', 'Copyright &copy; 2013. Homshop.') ||
			!Configuration::updateGlobalValue('predefined_color', 'default') ||
			!Configuration::updateGlobalValue('use_custom_colors', 'off') ||
			!Configuration::updateGlobalValue('bg_color', 'ffffff') ||
			!Configuration::updateGlobalValue('main_color', '78a213') ||
			!Configuration::updateGlobalValue('secondary_color', 'e48a20') ||
			!Configuration::updateGlobalValue('section_bg_color', 'dfdfe0') ||
			!Configuration::updateGlobalValue('main_text_color', '5c5c5c') ||
			!Configuration::updateGlobalValue('link_color', '888888') ||
			!Configuration::updateGlobalValue('use_custom_fonts', 'off') ||
			!Configuration::updateGlobalValue('main_font', 'Fjalla One') ||
			!Configuration::updateGlobalValue('heading_font', 'Fjalla One') ||
			!Configuration::updateGlobalValue('secondary_font', 'Josefin+Sans') ||
			!Configuration::updateGlobalValue('custom_css', '') ||
			!Configuration::updateGlobalValue('topmenu_color', 'ececeb') ||
			!Configuration::updateGlobalValue('custom_js', '')
		)
			return false;
		return true;
	}

	private function uninstallDb()
	{
		if( !Configuration::deleteByName('titlepage_img') ||
			!Configuration::deleteByName('logo_top') ||
			!Configuration::deleteByName('logo_left') ||
			!Configuration::deleteByName('theme_responsive') ||
			!Configuration::deleteByName('footer_bg') ||
			!Configuration::deleteByName('sidebar_position') ||
			!Configuration::deleteByName('footer_bg') ||
			!Configuration::deleteByName('footer_copyright_text') ||
			!Configuration::deleteByName('predefined_color') ||
			!Configuration::deleteByName('use_custom_colors') ||
			!Configuration::deleteByName('bg_color') ||
			!Configuration::deleteByName('main_color') ||
			!Configuration::deleteByName('secondary_color') ||
			!Configuration::deleteByName('section_bg_color') ||
			!Configuration::deleteByName('main_text_color') ||
			!Configuration::deleteByName('link_color') ||
			!Configuration::deleteByName('use_custom_fonts') ||
			!Configuration::deleteByName('main_font') ||
			!Configuration::deleteByName('heading_font') ||
			!Configuration::deleteByName('secondary_font') ||
			!Configuration::deleteByName('custom_css') ||
			!Configuration::deleteByName('topmenu_color') ||
			!Configuration::deleteByName('custom_js')
		)
			return false;
		return true;
	}

	public function getContent()
	{
		//Add color picker JS and CSS
		$this->_html .= '<link rel="stylesheet" media="screen" type="text/css" href="'.$this->_path.'colorpicker/css/colorpicker.css" />';
		$this->_html .= '<script type="text/javascript" src="'.$this->_path.'colorpicker/js/colorpicker.js"></script>';
		$this->_html .= "<script type='text/javascript'>
						$(document).ready(function(){
							$('#topmenu_color, #bg_color, #main_color, #secondary_color, #section_bg_color, #main_text_color, #link_color').ColorPicker({
								onSubmit: function(hsb, hex, rgb, el) {
									$(el).val(hex);
									$(el).ColorPickerHide();
								},
								onBeforeShow: function () {
									$(this).ColorPickerSetColor(this.value);
								}
							})
							.bind('keyup', function(){
								$(this).ColorPickerSetColor(this.value);
							});
						});</script>";
	
		$output = '<h2>'.$this->displayName.'</h2>';
		if (Tools::isSubmit('submitThemeSettings'))
		{
			//Upload images
			$this->processImages();

			//Process forms
			$this->processForms();
			
			//HTML
			$footer_copyright_text = htmlentities(Tools::getValue('footer_copyright_text'), ENT_QUOTES | ENT_IGNORE, "UTF-8");
			$custom_css = htmlentities(Tools::getValue('custom_css'), ENT_QUOTES | ENT_IGNORE, "UTF-8");
			$custom_js = htmlentities(Tools::getValue('custom_js'), ENT_QUOTES | ENT_IGNORE, "UTF-8");

			//Update DB with form data
			Configuration::updateValue('titlepage_img', $this->image[1]);
			Configuration::updateValue('logo_top', Tools::getValue('logo_top'));
			Configuration::updateValue('logo_left', Tools::getValue('logo_left'));
			Configuration::updateValue('theme_responsive', Tools::getValue('theme_responsive'));
			Configuration::updateValue('sidebar_position', Tools::getValue('sidebar_position'));
			Configuration::updateValue('footer_bg', Tools::getValue('footer_bg'));
			Configuration::updateValue('footer_copyright_text', $footer_copyright_text);
			Configuration::updateValue('predefined_color', Tools::getValue('predefined_color'));
			Configuration::updateValue('use_custom_colors', Tools::getValue('use_custom_colors'));
			Configuration::updateValue('bg_color', Tools::getValue('bg_color'));
			Configuration::updateValue('main_color', Tools::getValue('main_color'));
			Configuration::updateValue('secondary_color', Tools::getValue('secondary_color'));
			Configuration::updateValue('section_bg_color', Tools::getValue('section_bg_color'));
			Configuration::updateValue('main_text_color', Tools::getValue('main_text_color'));
			Configuration::updateValue('link_color', Tools::getValue('link_color'));
			Configuration::updateValue('use_custom_fonts', Tools::getValue('use_custom_fonts'));
			Configuration::updateValue('main_font', Tools::getValue('main_font'));
			Configuration::updateValue('heading_font', Tools::getValue('heading_font'));
			Configuration::updateValue('secondary_font', Tools::getValue('secondary_font'));
			Configuration::updateValue('topmenu_color', Tools::getValue('topmenu_color'));
			Configuration::updateValue('custom_css', $custom_css);
			Configuration::updateValue('custom_js', $custom_js);

			//Display message
			$output .= $this->displayConfirmation($this->l('Your settings have been updated.'));
		}
		
		return $this->_html.$output.$this->displayForm();
	}

	public function displayForm()
	{
		if (!is_writable('.'))
			$this->adminDisplayWarning(sprintf($this->l('Module %s must be writable (CHMOD 755 / 777)'), $this->name));

		//Get existing info from DB
		$titlepage_img = Configuration::get('titlepage_img');
		$logo_top = Configuration::get('logo_top');
		$logo_left = Configuration::get('logo_left');
		$responsive = Configuration::get('theme_responsive');
		$sidebar_position = Configuration::get('sidebar_position');
		$footer_bg = Configuration::get('footer_bg');
		$footer_copyright_text = Configuration::get('footer_copyright_text');
		$predefined_color = Configuration::get('predefined_color');
		$use_custom_colors = Configuration::get('use_custom_colors');
		$bg_color = Configuration::get('bg_color');
		$main_color = Configuration::get('main_color');
		$secondary_color = Configuration::get('secondary_color');
		$section_bg_color = Configuration::get('section_bg_color');
		$main_text_color = Configuration::get('main_text_color');
		$link_color = Configuration::get('link_color');
		$use_custom_fonts = Configuration::get('use_custom_fonts');
		$main_font = Configuration::get('main_font');
		$heading_font = Configuration::get('heading_font');
		$secondary_font = Configuration::get('secondary_font');
		$custom_css = Configuration::get('custom_css');
		$topmenu_color = Configuration::get('topmenu_color');
		$custom_js = Configuration::get('custom_js');
		
		//Remove image script
		$output = "
			<script>
				$('document').ready( function() {
					$('.removeimg1').click(function(){
						$('.remove_1').val('1');
						$('.current_1').hide();
					});
				});
			</script>
		";

		//Font list
		$font_list_default = array();
		$font_list_default['Helvetica'] = 'Helvetica';
		$font_list_default['Arial'] = 'Arial';
		$font_list_default['sans-serif'] = 'Sans Serif';
		$font_list = array_merge( $font_list_default, array( 'Fjalla One' => 'Fjalla One','Exo' => 'Exo', 'Roboto' => 'Roboto', 'Source+Sans+Pro' => 'Source Sans Pro', 'Titillium+Web' => 'Titillium Web', 'Josefin+Sans' => 'Josefin Sans', 'Josefin+Slab' => 'Josefin Slab', 'Lato' => 'Lato', 'Open+Sans' => 'Open Sans', 'Raleway' => 'Raleway', 'Cabin' => 'Cabin', 'Expletus+Sans' => 'Expletus Sans', 'Ubuntu' => 'Ubuntu', 'Advent+Pro' => 'Advent Pro', 'Dosis' => 'Dosis', 'Source+Code+Pro' => 'Source Code Pro', 'Alegreya' => 'Alegreya', 'Alegreya+SC' => 'Alegreya SC', 'Averia+Libre' => 'Averia Libre', 'Averia+Sans+Libre' => 'Averia Sans Libre', 'Averia+Serif+Libre' => 'Averia Serif Libre', 'Crimson+Text' => 'Crimson Text', 'Neuton' => 'Neuton', 'Overlock' => 'Overlock', 'Playfair+Display' => 'Playfair Display', 'Playfair+Display+SC' => 'Playfair Display SC', 'Roboto+Condensed' => 'Roboto Condensed', 'Almendra' => 'Almendra', 'Amaranth' => 'Amaranth', 'Anonymous+Pro' => 'Anonymous Pro', 'Archivo+Narrow' => 'Archivo Narrow', 'Arimo' => 'Arimo', 'Arvo' => 'Arvo', 'Asap' => 'Asap', 'Cabin+Condensed' => 'Cabin Condensed', 'Cantarell' => 'Cantarell', 'Caudex' => 'Caudex', 'Chivo' => 'Chivo', 'Cousine' => 'Cousine', 'Cuprum' => 'Cuprum', 'Droid+Serif' => 'Droid Serif', 'Economica' => 'Economica', 'GFS+Neohellenic' => 'GFS Neohellenic', 'Gentium+Basic' => 'Gentium Basic', 'Gentium+Book+Basic' => 'Gentium Book Basic', 'Istok+Web' => 'Istok Web', 'Jura' => 'Jura', 'Karla' => 'Karla', 'Lobster+Two' => 'Lobster Two', 'Lora' => 'Lora', 'Marvel' => 'Marvel', 'Maven+Pro' => 'Maven Pro', 'Merriweather' => 'Merriweather', 'Muli' => 'Muli', 'Nobile' => 'Nobile', 'Noticia+Text' => 'Noticia Text', 'Orbitron' => 'Orbitron', 'PT+Sans' => 'PT Sans', 'PT+Serif' => 'PT Serif', 'Philosopher' => 'Philosopher', 'Puritan' => 'Puritan', 'Quantico' => 'Quantico', 'Quattrocento+Sans' => 'Quattrocento Sans', 'Rambla' => 'Rambla', 'Rosario' => 'Rosario', 'Scada' => 'Scada', 'Share' => 'Share', 'Signika' => 'Signika', 'Signika+Negative' => 'Signika Negative', 'Simonetta' => 'Simonetta', 'Tinos' => 'Tinos', 'Ubuntu+Mono' => 'Ubuntu Mono', 'Volkhov' => 'Volkhov', 'Vollkorn' => 'Vollkorn', 'Yanone+Kaffeesatz' => 'Yanone Kaffeesatz', 'BenchNine' => 'BenchNine', 'Bitter' => 'Bitter', 'Cardo' => 'Cardo', 'Cinzel' => 'Cinzel', 'Cinzel+Decorative' => 'Cinzel Decorative', 'Comfortaa' => 'Comfortaa', 'Gudea' => 'Gudea', 'Judson' => 'Judson', 'Kreon' => 'Kreon', 'Lekton' => 'Lekton', 'Libre+Baskerville' => 'Libre Baskerville', 'Nunito' => 'Nunito', 'Old+Standard+TT' => 'Old Standard TT', 'Open+Sans+Condensed' => 'Open Sans Condensed', 'Oswald' => 'Oswald', 'Oxygen' => 'Oxygen', 'Passion+One' => 'Passion One', 'Quicksand' => 'Quicksand', 'Ruda' => 'Ruda', 'Tienne' => 'Tienne', 'Trochut' => 'Trochut', 'ABeeZee' => 'ABeeZee', 'Allan' => 'Allan', 'Amatic+SC' => 'Amatic SC', 'Arapey' => 'Arapey', 'Astloch' => 'Astloch', 'Asul' => 'Asul', 'Battambang' => 'Battambang', 'Buenard' => 'Buenard', 'Cabin+Sketch' => 'Cabin Sketch', 'Changa+One' => 'Changa One', 'Chau+Philomene+One' => 'Chau Philomene One', 'Cherry+Swash' => 'Cherry Swash', 'Coda' => 'Coda', 'Codystar' => 'Codystar', 'Content' => 'Content', 'Corben' => 'Corben', 'Coustard' => 'Coustard', 'Crete+Round' => 'Crete Round', 'Dancing+Script' => 'Dancing Script', 'Delius+Unicase' => 'Delius Unicase', 'Domine' => 'Domine', 'Droid+Sans' => 'Droid Sans', 'Elsie' => 'Elsie', 'Elsie+Swash+Caps' => 'Elsie Swash Caps', 'Enriqueta' => 'Enriqueta', 'Fanwood+Text' => 'Fanwood Text', 'Flamenco' => 'Flamenco', 'Fondamento' => 'Fondamento', 'Geo' => 'Geo', 'Gorditas' => 'Gorditas', 'Hanuman' => 'Hanuman', 'IM+Fell+DW+Pica' => 'IM Fell DW Pica', 'IM+Fell+Double+Pica' => 'IM Fell Double Pica', 'IM+Fell+English' => 'IM Fell English', 'IM+Fell+French+Canon' => 'IM Fell French Canon', 'IM+Fell+Great+Primer' => 'IM Fell Great Primer', 'Inconsolata' => 'Inconsolata', 'Inika' => 'Inika', 'Kameron' => 'Kameron', 'Life+Savers' => 'Life Savers', 'Linden+Hill' => 'Linden Hill', 'Lusitana' => 'Lusitana', 'Magra' => 'Magra', 'Mate' => 'Mate', 'Merienda' => 'Merienda', 'Monda' => 'Monda', 'Montserrat' => 'Montserrat', 'Montserrat+Alternates' => 'Montserrat Alternates', 'Montserrat+Subrayada' => 'Montserrat Subrayada', 'Mountains+of+Christmas' => 'Mountains of Christmas', 'News+Cycle' => 'News Cycle', 'Nokora' => 'Nokora', 'Oleo+Script' => 'Oleo Script', 'Oleo+Script+Swash+Caps' => 'Oleo Script Swash Caps', 'Oregano' => 'Oregano', 'PT+Sans+Caption' => 'PT Sans Caption', 'PT+Sans+Narrow' => 'PT Sans Narrow', 'PT+Serif+Caption' => 'PT Serif Caption', 'Play' => 'Play', 'Podkova' => 'Podkova', 'Poly' => 'Poly', 'Quattrocento' => 'Quattrocento', 'Radley' => 'Radley', 'Rokkitt' => 'Rokkitt', 'Ropa+Sans' => 'Ropa Sans', 'Rosarivo' => 'Rosarivo', 'Rufina' => 'Rufina', 'Sanchez' => 'Sanchez', 'Skranji' => 'Skranji', 'Sorts+Mill+Goudy' => 'Sorts Mill Goudy', 'Stardos+Stencil' => 'Stardos Stencil', 'Stoke' => 'Stoke', 'Syncopate' => 'Syncopate', 'Tangerine' => 'Tangerine', 'Unkempt' => 'Unkempt' ) );


		/* General 
		***************************/
		
		$output .= '
		
		<form action="'.Tools::safeOutput($_SERVER['REQUEST_URI']).'" method="post" enctype="multipart/form-data">
			<fieldset><legend>'.$this->l('General').'</legend>
		<label>'.$this->l('Enable Responsive').'</label>
				<div class="margin-form">
					<input type="radio" name="theme_responsive" value="on" id="ron" '.( $responsive == 'on' ? 'checked="checked"' : '' ).'><label class="t" for="ron">On</label>
					<input type="radio" name="theme_responsive" value="off" id="roff" '.( $responsive == 'off' ? 'checked="checked"' : '' ).'> <label class="t" for="roff">Off</label>
					<p class="clear">'.$this->l('Turn responsiveness on/off').'</p>
				</div>';
		
		

		
				
		$output .= '<label for="logo_top">'.$this->l('Logo position top').'</label>
				<div class="margin-form">
					<input type="text" name="logo_top" id="logo_top" value="'.$logo_top.'" />
					<p class="clear">'.$this->l('Value in pixels. Enter only value, do not use units, for example: 40').'</p>
				</div>';
				
		$output .= '<label for="logo_top">'.$this->l('Logo position left').'</label>
				<div class="margin-form">
					<input type="text" name="logo_left" id="logo_left" value="'.$logo_left.'" />
					<p class="clear">'.$this->l('Value in pixels. Enter only value, do not use units, for example: 40').'</p>
				</div>';
				
		$output .= '<label>'.$this->l('Column position').'</label>
				<div class="margin-form">
					<input type="radio" name="sidebar_position" value="left" id="sleft" '.( $sidebar_position == 'left' ? 'checked="checked"' : '' ).'><label class="t" for="sleft">Left</label>
					<input type="radio" name="sidebar_position" value="right" id="sright" '.( $sidebar_position == 'right' ? 'checked="checked"' : '' ).'> <label class="t" for="sright">Right</label>
					<input type="radio" name="sidebar_position" value="off" id="soff" '.( $sidebar_position == 'off' ? 'checked="checked"' : '' ).'> <label class="t" for="soff">Don\'t show sidebar</label>
					<p class="clear">'.$this->l('Choose column position (left or right column) or turn it off (category page only)').'</p>
					<p class="clear">'.$this->l('if you turn off the column, disable the layered navigation module, otherwise your product page might not function properly').'</p>
				</div>';
				
		$output .= '
		
				<label>'.$this->l('Title Page Image').'</label>
				<div class="margin-form">
					<input type="file" name="image_1" id="image_1" size="30" />
					<p class="clear">'.$this->l('Upload image for Title Page section - located on all pages under header').'</p>
				</div>';

		if($titlepage_img != '')
		{
			$output .= '<input type="hidden" name="image_old_1" value="'.$titlepage_img.'" />';
			$output .= '<input type="hidden" name="remove_1" class="remove_1" value="0" />';
			
			$output .= '<div class="current_1"><label>'.$this->l('Image').'</label>
						<div class="margin-form">
							<img src="'.$this->_path.'images/'.$titlepage_img.'" border="0" height="100" width="300" />
							<p class="clear removeimg1" style="cursor: pointer;">'.$this->l('Click here to remove image (use this if you\'re not uploading a new image and don\'t want to use an image at all in this column)').'</p>
						</div>
						</div>';
		}		
				

		$output .= '<label for="footer_copyright_text">'.$this->l('Copyright footer').'</label>
				<div class="margin-form">
					<textarea name="footer_copyright_text" id="footer_copyright_text" style="width: 350px; height: 120px;">'.$footer_copyright_text.'</textarea>
					<p class="clear">'.$this->l('Copyright in the footer (HTML enabled).').'</p>
				</div>
			</fieldset><br/>';

		/*Color 
		***************************/
		$output .= '<fieldset><legend>'.$this->l('Color').'</legend>
				<label for="predefined_color">'.$this->l('Choose defaut skin').'</label>
				<div class="margin-form">
					<select name="predefined_color" id="predefined_color">
						<option value="default" '.($predefined_color == 'default' ? 'selected="selected"' : '').'>Default</option>
						<option value="brown" '.($predefined_color == 'brown' ? 'selected="selected"' : '').'>Brown</option>
						<option value="pink" '.($predefined_color == 'pink' ? 'selected="selected"' : '').'>Pink</option>
						<option value="red" '.($predefined_color == 'red' ? 'selected="selected"' : '').'>Red</option>	
						<option value="grey" '.($predefined_color == 'grey' ? 'selected="selected"' : '').'>Grey</option>
						<option value="orange" '.($predefined_color == 'orange' ? 'selected="selected"' : '').'>Orange</option>
						<option value="purple" '.($predefined_color == 'purple' ? 'selected="selected"' : '').'>Purple</option>
						<option value="blue" '.($predefined_color == 'blue' ? 'selected="selected"' : '').'>Blue</option>
						
						<
					</select>
					<p class="clear">'.$this->l('Use one of the predefined skin').'</p>
				</div>';

		$output .= '<label>'.$this->l('Use custom colors').'</label>
				<div class="margin-form">
					<input type="radio" name="use_custom_colors" value="on" id="con" '.( $use_custom_colors == 'on' ? 'checked="checked"' : '' ).'><label class="t" for="con">Yes</label>
					<input type="radio" name="use_custom_colors" value="off" id="coff" '.( $use_custom_colors == 'off' ? 'checked="checked"' : '' ).'> <label class="t" for="coff">No</label>
					<p class="clear">'.$this->l('If you check this, colors defined below will apply').'</p>
				</div>

				<label for="bg_color">'.$this->l('Background Color').'</label>
				<div class="margin-form">
					<input type="text" name="bg_color" id="bg_color" value="'.$bg_color.'" />
				</div>
				
				<label for="topmenu_color">'.$this->l('Background Color top menu').'</label>
				<div class="margin-form">
					<input type="text" name="topmenu_color" id="topmenu_color" value="'.$topmenu_color.'" />
				</div>
				
				<label for="footer_bg">'.$this->l('Background Color footer').'</label>
				<div class="margin-form">
					<input type="text" name="footer_bg" id="footer_bg" value="'.$footer_bg.'" />
				</div>

				<label for="main_color">'.$this->l('Main Color').'</label>
				<div class="margin-form">
					<input type="text" name="main_color" id="main_color" value="'.$main_color.'" />
				</div>

				<label for="secondary_color">'.$this->l('Secondary Color').'</label>
				<div class="margin-form">
					<input type="text" name="secondary_color" id="secondary_color" value="'.$secondary_color.'" />
				</div>

				<label for="section_bg_color">'.$this->l('Section Background Color').'</label>
				<div class="margin-form">
					<input type="text" name="section_bg_color" id="section_bg_color" value="'.$section_bg_color.'" />
					<p class="clear">'.$this->l('Background color for the section block - full width, shown on the home and product pages').'</p>
				</div>

				<label for="main_text_color">'.$this->l('Main Text Color').'</label>
				<div class="margin-form">
					<input type="text" name="main_text_color" id="main_text_color" value="'.$main_text_color.'" />
				</div>

				<label for="link_color">'.$this->l('Link Color').'</label>
				<div class="margin-form">
					<input type="text" name="link_color" id="link_color" value="'.$link_color.'" />
				</div>
			</fieldset><br />';

		/*Font
		***************************/
		$output .= '<fieldset><legend>'.$this->l('Font').'</legend>
				<label>'.$this->l('Use custom fonts').'</label>
				<div class="margin-form">
					<input type="radio" name="use_custom_fonts" value="on" id="fon" '.( $use_custom_fonts == 'on' ? 'checked="checked"' : '' ).'><label class="t" for="fon">Yes</label>
					<input type="radio" name="use_custom_fonts" value="off" id="foff" '.( $use_custom_fonts == 'off' ? 'checked="checked"' : '' ).'> <label class="t" for="foff">No</label>
					<p class="clear">'.$this->l('If you check this, fonts defined below will apply').'</p>
				</div>

				<label for="main_font">'.$this->l('Main Font').'</label>
				<div class="margin-form">
					<select name="main_font" id="main_font">';
						foreach( $font_list as $value => $name )
							$output .= '<option value="'.$value.'" '.($main_font == $value ? 'selected="selected"' : '' ).'>'.$name.'</option>';
		$output .= '</select>
				</div>

				<label for="heading_font">'.$this->l('Heading Font').'</label>
				<div class="margin-form">
					<select name="heading_font" id="heading_font">';
						foreach( $font_list as $value => $name )
							$output .= '<option value="'.$value.'" '.($heading_font == $value ? 'selected="selected"' : '' ).'>'.$name.'</option>';
		$output .= '</select>
					<p class="clear">'.$this->l('Used mostly for headings - h1, h2, h3, h4, h5, h6').'</p>
				</div>

				<label for="secondary_font">'.$this->l('Secondary Font').'</label>
				<div class="margin-form">
					<select name="secondary_font" id="secondary_font">';
						foreach( $font_list as $value => $name )
							$output .= '<option value="'.$value.'" '.($secondary_font == $value ? 'selected="selected"' : '' ).'>'.$name.'</option>';
		$output .= '</select>
					<p class="clear">'.$this->l('Used for menu underlabels and other less important text').'</p>
				</div>
				</fieldset><br/>';
				
		/* Custom
		*/
		$output .= '<fieldset><legend>'.$this->l('Custom').'</legend>
				<label for="custom_css">'.$this->l('Add Custom CSS').'</label>
				<div class="margin-form">
					<textarea name="custom_css" id="custom_css" style="width: 350px; height: 120px;">'.$custom_css.'</textarea>
					<p class="clear">'.$this->l('You can add custom CSS here').'</p>
				</div>

				<label for="custom_js">'.$this->l('Add Custom JavaScript').'</label>
				<div class="margin-form">
					<textarea name="custom_js" id="custom_js" style="width: 350px; height: 120px;">'.$custom_js.'</textarea>
					<p class="clear">'.$this->l('You can add custom JavaScript here, Google Analytics, for example, and anything else').'</p>
				</div>
				</fieldset><br/>';

		$output .= '
			<center><input type="submit" name="submitThemeSettings" value="'.$this->l('Save').'" class="button" /></center>
		</form>';

		return $output;
	}

	public function processForms()
	{
		//Delete pagetitle image
		if(Tools::getValue('remove_1') == '1')
		{
			if($this->image[1] != 'titlepage.png')
			{
			//Delete image
			if ($this->image[1] && file_exists(dirname(__FILE__).'/images/'.$this->image[1]))
				$res = @unlink(dirname(__FILE__).'/images/'.$this->image[1]);
			}

			$this->image[1] = '';
		}
	}

	public function processImages()
	{
		$i = 1;
		foreach($_FILES as $value)
		{
			if(isset($_FILES['image_'.$i]))
			{
				$type = strtolower(substr(strrchr($_FILES['image_'.$i]['name'], '.'), 1));
				$imagesize = array();
				$imagesize = @getimagesize($_FILES['image_'.$i]['tmp_name']);
			}

			if (isset($_FILES['image_'.$i]) &&
				isset($_FILES['image_'.$i]['tmp_name']) &&
				!empty($_FILES['image_'.$i]['tmp_name']) &&
				!empty($imagesize) &&
				in_array(strtolower(substr(strrchr($imagesize['mime'], '/'), 1)), array('jpg', 'gif', 'jpeg', 'png')) &&
				in_array($type, array('jpg', 'gif', 'jpeg', 'png')))
			{
				$temp_name = tempnam(_PS_TMP_IMG_DIR_, 'PS');
				$salt = sha1(microtime());
				if ($error = ImageManager::validateUpload($_FILES['image_'.$i]))
					$errors[] = $error;
				elseif (!$temp_name || !move_uploaded_file($_FILES['image_'.$i]['tmp_name'], $temp_name))
					return false;
				elseif (!ImageManager::resize($temp_name, dirname(__FILE__).'/images/'.Tools::encrypt($_FILES['image_'.$i]['name'].$salt).'.'.$type, null, null, $type))
					$errors[] = $this->displayError($this->l('An error occurred during the image upload process.'));
				if (isset($temp_name))
						@unlink($temp_name);
				$this->image[$i] = Tools::encrypt($_FILES['image_'.($i)]['name'].$salt).'.'.$type;
			}
			elseif (Tools::getValue('image_old_'.$i) != '')
				$this->image[$i] = Tools::getValue('image_old_'.$i);

			$i++;
		}
	}

	public function hookDisplayHeader($params)
	{
		//Get existing info from DB
		$titlepage_img = Configuration::get('titlepage_img');
		$logo_top = Configuration::get('logo_top');
		$logo_left = Configuration::get('logo_left');
		$responsive = Configuration::get('theme_responsive');
		$sidebar_position = Configuration::get('sidebar_position');
		$footer_bg = Configuration::get('footer_bg');
		$footer_copyright_text = Configuration::get('footer_copyright_text');
		$predefined_color = Configuration::get('predefined_color');
		$use_custom_colors = Configuration::get('use_custom_colors');
		$bg_color = Configuration::get('bg_color');
		$main_color = Configuration::get('main_color');
		$secondary_color = Configuration::get('secondary_color');
		$section_bg_color = Configuration::get('section_bg_color');
		$main_text_color = Configuration::get('main_text_color');
		$link_color = Configuration::get('link_color');
		$use_custom_fonts = Configuration::get('use_custom_fonts');
		$main_font = Configuration::get('main_font');
		$heading_font = Configuration::get('heading_font');
		$secondary_font = Configuration::get('secondary_font');
		$custom_css = Configuration::get('custom_css');
		$custom_js = Configuration::get('custom_js');
		$topmenu_color = Configuration::get('topmenu_color');

		//Custom fonts
		if($use_custom_fonts == 'on')
		{
			if($main_font != 'Helvetica' && $main_font != 'Arial' && $main_font != 'sans-serif')
			{
				$main_font_g = 1;
				$this->google_fonts_link = "<link href='http://fonts.googleapis.com/css?family=".$main_font.":400,300' rel='stylesheet' type='text/css'>";
			}

			if($heading_font != 'Helvetica' && $heading_font != 'Arial' && $heading_font != 'sans-serif')
			{
				$heading_font_g = 1;
				$this->google_fonts_link .= "<link href='http://fonts.googleapis.com/css?family=".$heading_font.":400,300,500' rel='stylesheet' type='text/css'>";
			}
				
			if($secondary_font != 'Helvetica' && $secondary_font != 'Arial' && $secondary_font != 'sans-serif')
			{
				$secondary_font_g = 1;
				$this->google_fonts_link .= "<link href='http://fonts.googleapis.com/css?family=".$secondary_font.":400,300' rel='stylesheet' type='text/css'>";
			}
				
			$this->google_fonts_link .= "\n\n";
			
			$this->google_fonts_link .= '<style>';
			
			//Main font
			if( isset($main_font_g) )
				$main_font = str_replace('+', ' ', $main_font);
			$this->google_fonts_link .= "body, input, select, button, textarea, #nav ul li a, #nav ul li a:visited, #nav .mega_menu, .under_slider .desc, .product_list .price_container, .our_price_display, #product_comments_block_extra { font-family: '".$main_font."', sans-serif; }";

			//Heading font
			if( isset($heading_font_g) )
				$heading_font = str_replace('+', ' ', $heading_font);
			$this->google_fonts_link .= "h1, h2, h3, h4, h5, h6, table th, table.table_block th, #top-menu, .pagetitle .breadcrumbs, .product_list .view_product, .product_list .product_name, .product_image_container .new, .product_image_container .sale, #image-block .sale, .product_attributes, .product_attributes label, #product_comments_block_extra .comments_note span, #layered_block_left .layered_subtitle { font-family: '".$heading_font."', sans-serif; }";

			//Secondary font
			if( isset($secondary_font_g) )
				$secondary_font = str_replace('+', ' ', $secondary_font);
			$this->google_fonts_link .= "#header_right #currencies_block_top, #header_right #languages_block_top, ul#header_links, #nav .underlabel, .product_list .product_category, #old_price_display, .subfooter, .footer ul li, .contact_info, .contact_info pre, .newsletter_footer { font-family: '".$secondary_font."', sans-serif; }";

			$this->google_fonts_link .= '</style>';
				
		}

		//Logo custom position
		if($logo_top != '80' || $logo_left != '20') {
			$this->logo_style = '#header_logo { top: '.$logo_top.'px; left: '.$logo_left.'px; }';

			$this->logo_style .= '@media only screen and (min-width: 600px) and (max-width: 899px) { #header_logo { position: absolute; top: '.$logo_top.'px; left: '.$logo_left.'px; } }
			@media only screen and (min-width: 1px) and (max-width: 599px) { #header_logo { position: absolute; top: '.$logo_top.'px; left: 0; width: 100%; text-align: center; } }';
		}
			
		//Custom colors
		if($use_custom_colors == 'on')
		{
			//Background color & main text color
			$this->custom_colors .= 'body { background-color: #'.$bg_color.'; color: #'.$main_text_color.'; }';


			//Main color
			$this->custom_colors .= 'a:hover, .warning_inline, .required, .warning a:hover, .form_style .required label sup, #nav li.sfHoverForce a, #nav a:hover, #nav li:hover a, #nav ul li a:hover, .section a:hover, .product_list .product_category, .pagination ul a:hover, .pagination ul .current span, #usefull_link_block li:hover, .our_price_display, .block li a:hover, .block_content li a.selected, div.tags_block p a:hover, .s_title_block a:hover { color: #'.$main_color.'; }';

			$this->custom_colors .= '.error,input[type=submit], input[type=button], button, .button, .button:link, .button:visited, .ac_results .ac_over, .product_list li:hover .bottom_border_container .right, .idTabs .selected, #new_comment_form button, .ui-slider-horizontal .ui-slider-range, .step li.step_current span, .newsletter_footer input[type=submit], .product_image_container .sale, #image-block .sale, .under_slider .icon { background: #'.$main_color.'; }';
			
			$this->custom_colors .= '#nav ul li a:hover { background: #'.$main_color.' !important; }';

			$this->custom_colors .= 'pagination ul a:hover, .product_attributes #color_to_pick_list li.selected, .myaccount_lnk_list li a:hover, .favoriteproduct:hover, .pagination ul a:hover { border-color: #'.$main_color.'; }';

			$this->custom_colors .= '.newsletter_footer input[type=submit] { border: 0; }';

			//Secondary color
			$this->custom_colors .= '.warning, input[type=submit]:hover, input[type=button]:hover, button:hover, .button:hover, .button.secondary:hover, .product_image_container .new, .product_num_buttons .product_plus:hover, .product_num_buttons .product_minus:hover, #new_comment_form button:hover, .step li.step_done a, .step li.step_current_end a, .step li.step_current_end span, .product_list li:hover .bottom_border_container .left, .under_slider .desc:hover .icon { background: #'.$secondary_color.'; }';

			//Section background
			$this->custom_colors .= '.section { background: #'.$section_bg_color.'; }';

			//Link color
			$this->custom_colors .= 'a:link, a:visited { color: #'.$link_color.'; }';
			
			$this->custom_colors .= 'a:hover { color: #'.$main_color.'; }';
			
			
			//Topmenu background color
			$this->custom_colors .= '.navigation_container { background: #'.$topmenu_color.'; }';
			
			//Footer background color
			$this->custom_colors .= '.footer { background: #'.$footer_bg.'; }';
		}

		$this->context->smarty->assign(array(
			'titlepage_img' => ($titlepage_img != '') ? $this->_path.'images/'.$titlepage_img : '',
			'logo_style' => $this->logo_style,
			'responsive' => $responsive,
			'sidebar_position' => $sidebar_position,
			'footer_copyright_text' => $footer_copyright_text,
			'predefined_color' => $predefined_color,
			'use_custom_colors' => $use_custom_colors,
			'bg_color' => $bg_color,
			'topmenu_color' => $topmenu_color,
			'main_color' => $main_color,
			'secondary_color' => $secondary_color,
			'section_bg_color' => $section_bg_color,
			'main_text_color' => $main_text_color,
			'link_color' => $link_color,
			'use_custom_fonts' => $use_custom_fonts,
			'google_fonts_link' => $this->google_fonts_link,
			'custom_css' => $custom_css,
			'custom_js' => $custom_js, 
			'custom_color_style' => $this->custom_colors,
			
		));
	}
}