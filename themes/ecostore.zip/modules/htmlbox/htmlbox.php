<?php 
class htmlbox extends Module {
	function __construct(){
		$this->name = 'htmlbox';
		$this->tab = 'front_office_features';
        $this->author = 'MyPresta.eu';
		$this->version = '1.4.2';
        $this->dir = '/modules/htmlbox/';
		parent::__construct();
		$this->displayName = $this->l('HTMLbox');
		$this->description = $this->l('With this module you can put the HTML/JavaScript/CSS code anywhere you want');
        
	}
    
    

    static function remove_doublewhitespace($s = null){
           return  $ret = preg_replace('/([\s])\1+/', ' ', $s);
    }

    static function remove_whitespace($s = null){
           $ret = preg_replace('/[\s]+/', '', $s );
           $ret = mysql_escape_string($ret);
           return $ret;
    }

    static function remove_whitespace_feed( $s = null){
           return $ret = preg_replace('/[\t\n\r\0\x0B]/', ' ', $s);
    }

    static function smart_clean($s = null){
           return $ret = trim( self::remove_doublewhitespace( self::remove_whitespace_feed($s) ) );
    }


    
	function install(){
        if (parent::install() == false 
	    OR $this->registerHook('header') == false
	    OR $this->registerHook('top') == false
	    OR $this->registerHook('leftColumn') == false
	    OR $this->registerHook('rightColumn') == false
	    OR $this->registerHook('footer') == false
	    OR $this->registerHook('home') == false
        OR Configuration::updateValue('htmlbox_header', '0') == false
        OR Configuration::updateValue('htmlbox_top', '1') == false
        OR Configuration::updateValue('htmlbox_leftcol', '0') == false
        OR Configuration::updateValue('htmlbox_rightcol', '0') == false
        OR Configuration::updateValue('htmlbox_footercol', '0') == false
        OR Configuration::updateValue('htmlbox_homecol', '0') == false
        OR Configuration::updateValue('htmlbox_body', 'Tel 0800 - 54 - 56 - 44') == false
        ){
            return false;
        }
        return true;
	}
    
	public function getContent(){
	   	$output="";
		if (Tools::isSubmit('submit_settings')){
			$v=trim($_POST['htmlbox_body']);
            $v=self::smart_clean($v);
            $body=$v; 
            		
			Configuration::updateValue('htmlbox_body', $body, true);
            $output .= '<div class="conf confirm"><img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />'.$this->l('Settings updated').'</div>';
 			
			$hooks=$this->getsettingsofhtmlbox();
			foreach ($hooks['hook'] AS $hook=>$value){
					if ($hook==$_POST['htmlbox_hook']){
						$hookval=1;
					} else {
						$hookval=0;
					}
					
					Configuration::updateValue($hook,$hookval);
			}                                    
        }	   
        $output.="";
        return $output.$this->displayForm();
	}
    
    public function psversion() {
		$version=_PS_VERSION_;
		$exp=$explode=explode(".",$version);
		return $exp[1];
	}
    
	public function displayForm(){
			global $cookie;
            $iso = Language::getIsoById((int)($cookie->id_lang));
            $isoTinyMCE = (file_exists(_PS_ROOT_DIR_.'/js/tiny_mce/langs/'.$iso.'.js') ? $iso : 'en');
            $ad = dirname($_SERVER["PHP_SELF"]);

            if ($this->psversion()==5){
			$form='
			<script type="text/javascript" src="'.__PS_BASE_URI__.'js/tiny_mce/tiny_mce.js"></script>
			<script type="text/javascript">
			var iso = \''.$isoTinyMCE.'\' ;
			var pathCSS = \''._THEME_CSS_DIR_.'\' ;
			var ad = \''.$ad.'\' ;
			
			$(document).ready(function(){
			tinySetup({
				editor_selector :"rte",
        		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,fontselect,fontsizeselect",
        		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,codemagic,|,insertdate,inserttime,preview,|,forecolor,backcolor",
        		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
        		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft,visualblocks",
        		theme_advanced_toolbar_location : "top",
        		theme_advanced_toolbar_align : "left",
        		theme_advanced_statusbar_location : "bottom",
        		theme_advanced_resizing : false,
                extended_valid_elements: \'pre[*],script[*],style[*]\',
                valid_children: "+body[style|script],pre[script|div|p|br|span|img|style|h1|h2|h3|h4|h5],*[*]",
                valid_elements : \'*[*]\',
                force_p_newlines : false,
                cleanup: false,
                forced_root_block : false,
                force_br_newlines : true
				});
			});
			
			function addClass(){                    
				tinyMCE.execCommand(\'mceAddControl\', true, \'htmlbox_body\');
			}
			
			function removeClass(){
                  
				tinyMCE.execCommand(\'mceRemoveControl\', false, \'htmlbox_body\');
			}			
			
			</script>
			<script type="text/javascript" src="'.__PS_BASE_URI__.'js/tinymce.inc.js"></script>
			';
            } 
            
            if ($this->psversion()==4) {
             $form='
			<script type="text/javascript" src="'.__PS_BASE_URI__.'js/tiny_mce/tiny_mce.js"></script>
			<script type="text/javascript">
			var iso = \''.$isoTinyMCE.'\' ;
			var pathCSS = \''._THEME_CSS_DIR_.'\' ;
			var ad = \''.$ad.'\' ;
			
			$(document).ready(function(){
			tinyMCE.init({
			 mode : "specific_textareas",
    		 theme : "advanced",
    		 skin:"cirkuit",
    		 editor_selector :"rte",
        		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,fontselect,fontsizeselect",
        		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,codemagic,|,insertdate,inserttime,preview,|,forecolor,backcolor",
        		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
        		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft,visualblocks",
        		theme_advanced_toolbar_location : "top",
        		theme_advanced_toolbar_align : "left",
        		theme_advanced_statusbar_location : "bottom",
        		theme_advanced_resizing : false,
                extended_valid_elements: \'pre[*],script[*],style[*]\',
                valid_children: "+body[style|script],pre[script|div|p|br|span|img|style|h1|h2|h3|h4|h5]",
                force_p_newlines : false,
                cleanup: false,
                forced_root_block : false,
                force_br_newlines : true
				});
			});
			
			function addClass(){                    
				tinyMCE.execCommand(\'mceAddControl\', true, \'htmlbox_body\');
			}
			
			function removeClass(){
				tinyMCE.execCommand(\'mceRemoveControl\', false, \'htmlbox_body\');
			}			
			
			</script>
			<script type="text/javascript" src="'.__PS_BASE_URI__.'js/tinymce.inc.js"></script>
			';   
            }
            
            
            
            if ($this->psversion()==3) {
             $form='
			<script type="text/javascript" src="'.__PS_BASE_URI__.'js/tinymce/jscripts/tiny_mce/jquery.tinymce.js"></script>
		<script type="text/javascript">
        function addClass(){                    
				alert("doesnt work in 1.3");
			}
			
			function removeClass(){
				alert("doesnt work in 1.3");
			}
            
		function tinyMCEInit(element)
		{
			$().ready(function() {
				$(element).tinymce({
					// Location of TinyMCE script
					script_url : \''.__PS_BASE_URI__.'js/tinymce/jscripts/tiny_mce/tiny_mce.js\',
					// General options
					theme : "advanced",
					plugins : "safari,pagebreak,style,layer,table,advimage,advlink,inlinepopups,media,searchreplace,contextmenu,paste,directionality,fullscreen",
					// Theme options
					theme_advanced_buttons1 : "newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
					theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,,|,forecolor,backcolor",
					theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,media,|,ltr,rtl,|,fullscreen",
					theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,pagebreak",
					theme_advanced_toolbar_location : "top",
					theme_advanced_toolbar_align : "left",
					theme_advanced_statusbar_location : "bottom",
					theme_advanced_resizing : false,
					content_css : "'.__PS_BASE_URI__.'themes/'._THEME_NAME_.'/css/global.css",
					width: "582",
					height: "auto",
					font_size_style_values : "8pt, 10pt, 12pt, 14pt, 18pt, 24pt, 36pt",
					// Drop lists for link/image/media/template dialogs
					template_external_list_url : "lists/template_list.js",
					external_link_list_url : "lists/link_list.js",
					external_image_list_url : "lists/image_list.js",
					media_external_list_url : "lists/media_list.js",
					elements : "nourlconvert",
					convert_urls : false,
					language : "'.(file_exists(_PS_ROOT_DIR_.'/js/tinymce/jscripts/tiny_mce/langs/'.$iso.'.js') ? $iso : 'en').'"
				});
			});
		}
		tinyMCEInit(\'textarea.rte\');
		</script>';
        }
					
		$array=$this->getsettingsofhtmlbox();
		$radio="";   
		foreach ($array['hook'] as $key=>$value){
			if ($key=="htmlbox_leftcol"){$place=$this->l("left column");}
			if ($key=="htmlbox_rightcol"){$place=$this->l("right column");}
			if ($key=="htmlbox_top"){$place=$this->l("top");}
			if ($key=="htmlbox_header"){$place=$this->l("header");}
			if ($key=="htmlbox_footercol"){$place=$this->l("footer");}
			if ($key=="htmlbox_homecol"){$place=$this->l("home");}
			
			$selected=0;
			if ($value==1){
				$selected="checked";
			}
			$radio.="
				<tr>
					<td style=\"border-left:1px solid #c0c0c0; width:150px; padding:10px; background:#f2f2f2; border-bottom:1px solid #FFF; border-top:1px solid #c0c0c0; margin-right:10px;\">$place:</td>
					<td style=\"padding:10px; background:#fff; border-right:1px solid #c0c0c0;  border-bottom:1px solid #FFF; border-top:1px solid #c0c0c0; margin-right:10px;\"><input type=\"radio\" name=\"htmlbox_hook\" value=\"$key\" $selected style=\"cursor:pointer;\"/></td>
				</tr>
			";
		}
		return $form.'		
		<div style="diplay:block; clear:both; margin-bottom:20px;">
		<iframe src="http://mypresta.eu/content/uploads/2012/09/htmlbox_advertise.html" width="100%" height="130" border="0" style="border:none;"></iframe>
		</div>
		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
            <div style="display:block; margin:auto; overflow:hidden; width:100%; vertical-align:top;">
                    <div style="clear:both; display:block; vertical-align:top;">
						<fieldset style="height:412px; display:inline-block; width:200px; margin-right:10px; vertical-align:top;">
							<legend><img src="'.$this->_path.'logo.gif" alt="" title="" />'.$this->l('HTMLbox configuration').'</legend>   
          					<h3 style="margin-bottom:0px; padding-bottom:0px; margin-bottom:20px;">'.$this->l('Where to display HTMLbox ?').'</h3>
							<table style="border-bottom:1px solid #c0c0c0;  clear:both; vertical-align:top;" cellspacing="0" cellpadding="0">
							'.$radio.'
							</table>
						</fieldset>             
						
                        <fieldset style="display:inline-block; width:648px;  vertical-align:top;">
            				<legend><img src="'.$this->_path.'logo.gif" alt="" title="" />'.$this->l('HTMLbox configuration').'</legend>
                            <h3 style="margin-bottom:0px; padding-bottom:0px;">'.$this->l('Enter the HTML/js/css code here').'</h3>
                            '.$this->l('editor').': 
                            <span onclick="$(\'#htmlbox_body\').addClass(\'rte\'); addClass();" style="cursor:pointer;">'.$this->l('On').'</span> |
                            <span onclick="$(\'#htmlbox_body\').removeClass(\'rte\'); removeClass();" style="cursor:pointer;">'.$this->l('Off').'</span>
                            <hr style="margin-top:5px;">
       						<textarea type="text" style="margin-bottom:10px; width:99%; height:300px;" id="htmlbox_body" name="htmlbox_body">'.$array['body'].'</textarea>                                                                                                                                         
                            <div align="center">
       				        <input type="submit" name="submit_settings" value="'.$this->l('Save Settings').'" class="button" />
                            </div>
                        </fieldset>                    
                    </div>
            </div>
		</form>
        '.'<div style="float:right; text-align:right; display:inline-block; margin-top:10px; font-size:10px;">
        '.$this->l('Proudly developed by').' <a href="http://mypresta.eu" style="font-weight:bold; color:#B73737">MyPresta<font style="color:black;">.eu</font>.</a>
        </div>';  ;
	}   
   
    public function getsettingsofhtmlbox(){
        $array['hook']['htmlbox_header']= Configuration::get('htmlbox_header');
		$array['hook']['htmlbox_top']= Configuration::get('htmlbox_top');
		$array['hook']['htmlbox_leftcol']= Configuration::get('htmlbox_leftcol');
		$array['hook']['htmlbox_rightcol']= Configuration::get('htmlbox_rightcol');
		$array['hook']['htmlbox_footercol']= Configuration::get('htmlbox_footercol');
		$array['hook']['htmlbox_homecol']= Configuration::get('htmlbox_homecol'); 
		$array['body'] = str_replace(array("\rn", "\r", "\n"), array(' ',' ',' '),Configuration::get('htmlbox_body'));
		return $array;
    }
   
	function hookrightColumn($params){
		$array=$this->getsettingsofhtmlbox();
		if ($array['hook']['htmlbox_rightcol']=="1"){
	        global $smarty;
	        $smarty->assign(array('htmlboxbody' => nl2br(stripslashes($array['body']))));
			return $this->display(__FILE__, 'html.tpl');	
		}
	}	 
    
	function hookleftColumn($params){
		$array=$this->getsettingsofhtmlbox();
		if ($array['hook']['htmlbox_leftcol']=="1"){
	        global $smarty;
	        $smarty->assign(array('htmlboxbody' => nl2br(stripslashes($array['body']))));
			return $this->display(__FILE__, 'html.tpl');
		}
	}
    
	function hookhome($params){
		$array=$this->getsettingsofhtmlbox();
		if ($array['hook']['htmlbox_homecol']=="1"){
	        global $smarty;
	        $smarty->assign(array('htmlboxbody' => nl2br(stripslashes($array['body']))));
			return $this->display(__FILE__, 'html.tpl');	
		}
	}
    
	function hookfooter($params){
		$array=$this->getsettingsofhtmlbox();
		if ($array['hook']['htmlbox_footercol']=="1"){
	        global $smarty;
	        $smarty->assign(array('htmlboxbody' => nl2br(stripslashes($array['body']))));
			return $this->display(__FILE__, 'html.tpl');
		}
	} 
	 
	function hookheader($params){
		$array=$this->getsettingsofhtmlbox();
		if ($array['hook']['htmlbox_header']=="1"){
	        global $smarty;
	        $smarty->assign(array('htmlboxbody' => nl2br(stripslashes($array['body']))));
			return $this->display(__FILE__, 'html.tpl');
		}
	}

	function hooktop($params){
		$array=$this->getsettingsofhtmlbox();
		if ($array['hook']['htmlbox_top']=="1"){
	        global $smarty;
	        $smarty->assign(array('htmlboxbody' => nl2br(stripslashes($array['body']))));
			return $this->display(__FILE__, 'html.tpl');
		}
	} 	      
    
}
?>