<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{htmlbox}prestashop>htmlbox_66e0c17dd87ad977b7d3e3e2cbbc44a7'] = 'HTMLbox';
$_MODULE['<{htmlbox}prestashop>htmlbox_2a5b55f8f0ea547b659506ee561a1f1d'] = 'Pomocí tohoto modulu si můžete dát \"HTML / JavaScript / CSS\" kód kdekoli chcete';
$_MODULE['<{htmlbox}prestashop>htmlbox_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'potvrzení';
$_MODULE['<{htmlbox}prestashop>htmlbox_c888438d14855d7d96a2724ee9c306bd'] = 'Nastavení aktualizace';
$_MODULE['<{htmlbox}prestashop>htmlbox_83fc76a8bceb3526eda29c20add790b6'] = 'HTMLbox konfigurace';
$_MODULE['<{htmlbox}prestashop>htmlbox_54108d6986ee41288fa9d5b4fdec420c'] = 'Pokud se zobrazí HTMLbox?';
$_MODULE['<{htmlbox}prestashop>htmlbox_01090c774c1734d594584ec91fb7ab47'] = 'Zadejte HTML / JS / CSS kód zde';
$_MODULE['<{htmlbox}prestashop>htmlbox_5aee9dbd2a188839105073571bee1b1f'] = 'editor';
$_MODULE['<{htmlbox}prestashop>htmlbox_521c36a31c2762741cf0f8890cbe05e3'] = 'zapnout';
$_MODULE['<{htmlbox}prestashop>htmlbox_d15305d7a4e34e02489c74a5ef542f36'] = 'vypnout';
$_MODULE['<{htmlbox}prestashop>htmlbox_9daf1fb753b42c3cdc8f1d01669cd6d8'] = 'Uložit nastavení';
