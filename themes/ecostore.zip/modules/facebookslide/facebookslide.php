<?php
/*
* 2007-2012 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2012 PrestaShop SA
*  @version  Release: $Revision: 6844 $
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_CAN_LOAD_FILES_'))
	exit;
	
class Facebookslide extends Module
{
	public function __construct()
	{
		$this->name = 'facebookslide';
		$this->tab = 'front_office_features';
		$this->version = '1.0';
		
		parent::__construct();

		$this->displayName = $this->l('Facebook slide');
		$this->description = $this->l('Show facebook likebox');
	}
	
	public function install()
	{
		return (parent::install() AND Configuration::updateValue('fbmod_faces', '1') && Configuration::updateValue('fbmod_stream', '1')   && Configuration::updateValue('fbmod_position', '0')  && Configuration::updateValue('fbmod_link', 'http://www.facebook.com/prestashop') 
	&& $this->registerHook('displayHeader') && $this->registerHook('Facblock'));
	}
	
	public function uninstall()
	{
		//Delete configuration			
		return (Configuration::deleteByName('fbmod_faces') AND Configuration::deleteByName('fbmod_stream') AND Configuration::deleteByName('fbmod_link') AND Configuration::deleteByName('fbmod_position') AND parent::uninstall());
	}
	
	public function getContent()
	{
		// If we try to update the settings
		$output = '';
		if (isset($_POST['submitModule']))
		{	
			Configuration::updateValue('fbmod_link', $_POST['fbmod_link']);
			Configuration::updateValue('fbmod_faces', $_POST['fbmod_faces']);
			Configuration::updateValue('fbmod_stream', $_POST['fbmod_stream']);		
			Configuration::updateValue('fbmod_position', $_POST['fbmod_position']);	
			$output = '<div class="conf confirm">'.$this->l('Configuration updated').'</div>';
		}
		
		return '
		<h2>'.$this->displayName.'</h2>
		'.$output.'
		<form action="'.Tools::htmlentitiesutf8($_SERVER['REQUEST_URI']).'" method="post">
			<fieldset class="width2">	
			<label for="fbmod_faces">'.$this->l('Module position: ').'</label>
					<input type="radio" name="fbmod_position" id="fbmod_position_1" value="1" ' . ((Configuration::get('fbmod_position') == 1) ? 'checked="checked" ' : '') . '/>
					<label class="t" for="fbmod_position_1"> ' . $this -> l('Left') . '</label>
					<input type="radio" name="fbmod_position" id="fbmod_position_0" value="0" ' . ((Configuration::get('fbmod_position') == 0) ? 'checked="checked" ' : '') . '/>
					<label class="t" for="fbmod_position_0"> ' . $this -> l('Right') . '</label>
				<div class="clear">&nbsp;</div>		
				<label for="facebook_url">'.$this->l('Facebook URL: ').'</label>
				<input type="text" id="fbmod_link" name="fbmod_link" value="'.Tools::safeOutput((Configuration::get('fbmod_link') != "") ? Configuration::get('fbmod_link') : "").'" />
			<div class="margin-form">Example: https://www.facebook.com/prestashop</div>	
					
				<label for="fbmod_faces">'.$this->l('Show fans faces: ').'</label>
					<input type="radio" name="fbmod_faces" id="fbmod_faces_1" value="1" ' . ((Configuration::get('fbmod_faces') == 1) ? 'checked="checked" ' : '') . '/>
					<label class="t" for="fbmod_faces_1"> <img src="../img/admin/enabled.gif" alt="' . $this -> l('Enabled') . '" title="' . $this -> l('Enabled') . '" /></label>
					<input type="radio" name="fbmod_faces" id="fbmod_faces_0" value="0" ' . ((Configuration::get('fbmod_faces') == 0) ? 'checked="checked" ' : '') . '/>
					<label class="t" for="fbmod_faces_0"> <img src="../img/admin/disabled.gif" alt="' . $this -> l('Disabled') . '" title="' . $this -> l('Disabled') . '" /></label>
				<div class="clear">&nbsp;</div>		
				<label for="twitter_url">'.$this->l('Show stream: ').'</label>
									<input type="radio" name="fbmod_stream" id="fbmod_stream_1" value="1" ' . ((Configuration::get('fbmod_stream') == 1) ? 'checked="checked" ' : '') . '/>
					<label class="t" for="fbmod_stream_1"> <img src="../img/admin/enabled.gif" alt="' . $this -> l('Enabled') . '" title="' . $this -> l('Enabled') . '" /></label>
					<input type="radio" name="fbmod_stream" id="fbmod_stream_0" value="0" ' . ((Configuration::get('fbmod_stream') == 0) ? 'checked="checked" ' : '') . '/>
					<label class="t" for="fbmod_stream_0"> <img src="../img/admin/disabled.gif" alt="' . $this -> l('Disabled') . '" title="' . $this -> l('Disabled') . '" /></label>
				<div class="clear">&nbsp;</div>						
				<br /><center><input type="submit" name="submitModule" value="'.$this->l('Update settings').'" class="button" /></center>
			</fieldset>
		</form>';
	}
	
	public function hookDisplayHeader()
	{
		$this->context->controller->addCSS(($this->_path).'facebookslide.css', 'all');
		$this->context->controller->addJS(($this->_path).'facebookslide.js');
	}
		
		
	public function hookFacblock()
	{
		global $smarty;
	


		$smarty->assign(array(
			'fbmod_link' => Configuration::get('fbmod_link'),
			'fbmod_stream' => Configuration::get('fbmod_stream'),
			'fbmod_faces' => Configuration::get('fbmod_faces'),
			'fbmod_position' => Configuration::get('fbmod_position'),
		));
		return $this->display(__FILE__, 'facebookslide.tpl');
	}
}
?>
