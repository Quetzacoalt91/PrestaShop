<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{med_contactable}prestashop>med_contactable_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{med_contactable}prestashop>med_contactable_4c2a8fe7eaf24721cc7a9f0175115bd4'] = 'mensaje';
$_MODULE['<{med_contactable}prestashop>med_contactable_548e51fa67d541384e9585adf0db95dc'] = 'ENVIAR';
$_MODULE['<{med_contactable}prestashop>med_contactable_81a0129aa68e6890405e083e6267ccca'] = ' Gracias por tu mensaje';
$_MODULE['<{med_contactable}prestashop>med_contactable_ab336a47ea96b0157fe1ad5f9798b9c5'] = 'No dude en ponerse en contacto por favor, valoramos sus comentarios';
