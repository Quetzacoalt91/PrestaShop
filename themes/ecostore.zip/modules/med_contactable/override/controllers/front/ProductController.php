<?php
/*
 */
class ProductController extends ProductControllerCore {

	public function setMedia()
	{
//		die();
//		parent::setMedia();
		// if website is accessed by mobile device

		// @see FrontControllerCore::setMobileMedia()
		if ($this->context->getMobileDevice() != false)
		{
			$this->setMobileMedia();
			return true;
		}

		if (Tools::file_exists_cache(_PS_ROOT_DIR_.Tools::str_replace_once(__PS_BASE_URI__, DIRECTORY_SEPARATOR, _THEME_CSS_DIR_.'grid_prestashop.css')))
			$this->addCSS(_THEME_CSS_DIR_.'grid_prestashop.css', 'all');
		$this->addCSS(_THEME_CSS_DIR_.'global.css', 'all');
		$this->addjquery();
		$this->addjqueryPlugin('easing');
		$this->addJS(_PS_JS_DIR_.'tools.js');

		if (Tools::isSubmit('live_edit') && Tools::getValue('ad') && Tools::getAdminToken('AdminModulesPositions'.(int)Tab::getIdFromClassName('AdminModulesPositions').(int)Tools::getValue('id_employee')))
		{
			$this->addJqueryUI('ui.sortable');
			$this->addjqueryPlugin('fancybox');
			$this->addJS(_PS_JS_DIR_.'hookLiveEdit.js');
			$this->addCSS(_PS_CSS_DIR_.'jquery.fancybox-1.3.4.css', 'all'); // @TODO
		}
		if ($this->context->language->is_rtl)
			$this->addCSS(_THEME_CSS_DIR_.'rtl.css');

		// Execute Hook FrontController SetMedia
		Hook::exec('actionFrontControllerSetMedia', array());

		if (count($this->errors))
			return ;

		if ($this->context->getMobileDevice() == false)
		{
			$this->addCSS(_THEME_CSS_DIR_.'product.css');
//			$this->addCSS(_PS_CSS_DIR_.'jquery.fancybox-1.3.4.css', 'screen');
			$this->addCSS(_THEME_JS_DIR_.'fancybox/jquery.fancybox.css');
			$this->addJqueryPlugin(array('idTabs', 'scrollTo', 'serialScroll'));
			$this->addJS(array(
				_THEME_JS_DIR_.'fancybox/jquery.fancybox.js',
				_THEME_JS_DIR_.'tools.js',
				_THEME_JS_DIR_.'product.js'
			));
		}
		else
		{
			$this->addJqueryPlugin(array('scrollTo', 'serialScroll'));
			$this->addJS(array(
				_THEME_JS_DIR_.'tools.js',
				_THEME_MOBILE_JS_DIR_.'product.js',
				_THEME_MOBILE_JS_DIR_.'jquery.touch-gallery.js'
			));
		}

		if (Configuration::get('PS_DISPLAY_JQZOOM') == 1)
			$this->addJqueryPlugin('jqzoom');
	}

}