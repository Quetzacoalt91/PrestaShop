<?php //modified by module sd_translate version 1.0.3.0 on Tue, 07 May 2013 16:24:51 +0200

global $_MODULE;
$_MODULE = array();
$_MODULE['<{med_contactable}prestashop>med_contactable_720d4ea83cb526eca3e2ce3f068c94af'] = 'Ajouter un formulaire de contact';
$_MODULE['<{med_contactable}prestashop>med_contactable_3c0e6fd1b9137daa022e11100f9fc44c'] = 'Permet d\'ajouter facilement un formulaire de contact sur votre boutique';
$_MODULE['<{med_contactable}prestashop>med_contactable_4c5fb985ac3acf87b49c295c67baf03d'] = 'Don';
$_MODULE['<{med_contactable}prestashop>med_contactable_2a64c64b8e9bcd6f15c4796d2ef21d88'] = 'Merci pour l\'installation de ce module sur votre site Internet.';
$_MODULE['<{med_contactable}prestashop>med_contactable_3384622e86410fd01fa318fedc6a98ce'] = 'Offert par';
$_MODULE['<{med_contactable}prestashop>med_contactable_fcb4361e960621e9fb2565393fda01eb'] = ', qui vous aide à développer votre site e-commerce.';
$_MODULE['<{med_contactable}prestashop>med_contactable_1aa2e2ff6972016c11c692bfb5c43909'] = 'Annonces';
$_MODULE['<{med_contactable}prestashop>med_contactable_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{med_contactable}prestashop>med_contactable_6f485c1b8223b42949c14d209048338f'] = 'Un Message de Feedback de :';
$_MODULE['<{med_contactable}prestashop>med_contactable_548e51fa67d541384e9585adf0db95dc'] = 'ENVOYER';
$_MODULE['<{med_contactable}prestashop>med_contactable_81a0129aa68e6890405e083e6267ccca'] = 'Merci pour votre message';
$_MODULE['<{med_contactable}prestashop>med_contactable_43b50733dc44d3b2cd86014c2339cb3a'] = 'Désolé, mais votre message ne peut être envoyé, réessayez plus tard';
$_MODULE['<{med_contactable}prestashop>med_contactable_ab336a47ea96b0157fe1ad5f9798b9c5'] = 'N\'hésitez pas à nous contacter, nous apprécions vos suggestions et commentaires';

?>