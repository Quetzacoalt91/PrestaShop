<?php

	header("Location: ../");
	exit;

?>