<?php
 
	header("Location: ../");
	exit;

?>